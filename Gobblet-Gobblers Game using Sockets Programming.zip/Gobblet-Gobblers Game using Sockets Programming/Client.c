// client.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char buffer[1024] = {0};
    char input[100];

    sock = socket(AF_INET, SOCK_STREAM, 0);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    printf("Enter server IP address: ");
    char ip[100];
    scanf("%s", ip);

    inet_pton(AF_INET, ip, &serv_addr.sin_addr);

    connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        recv(sock, buffer, sizeof(buffer), 0);
        printf("%s", buffer);

        if (strstr(buffer, "Your move")) {
            fgets(input, sizeof(input), stdin);
            fgets(input, sizeof(input), stdin); // consume newline
            send(sock, input, strlen(input), 0);
        }
        if (strstr(buffer, "wins") || strstr(buffer, "draw")) {
            break;
        }
    }

    close(sock);
    return 0;
}
