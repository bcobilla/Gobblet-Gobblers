// server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

typedef struct {
    int player_id;
    int size;
} Cell;

typedef struct {
    int small;
    int medium;
    int large;
} Inventory;

Cell board[3][3];
Inventory inventories[3]; // 1-indexed (player 1 and player 2)

void print_board() {
    printf("\nBoard State:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j].player_id == 0) printf("[ ]");
            else if (board[i][j].player_id == 1) {
                if (board[i][j].size == 1) printf("[1s]");
                else if (board[i][j].size == 2) printf("[1m]");
                else printf("[1l]");
            } else {
                if (board[i][j].size == 1) printf("[2s]");
                else if (board[i][j].size == 2) printf("[2m]");
                else printf("[2l]");
            }
        }
        printf("\n");
    }
}

int is_valid_move(int player, int row, int col, int size) {
    if (row < 0 || row > 2 || col < 0 || col > 2) return 0;
    if (size < 1 || size > 3) return 0;

    // Check inventory
    Inventory *inv = &inventories[player];
    if ((size == 1 && inv->small <= 0) ||
        (size == 2 && inv->medium <= 0) ||
        (size == 3 && inv->large <= 0)) {
        return 0;
    }

    // Check board stacking
    if (board[row][col].size >= size) {
        return 0;
    }
    return 1;
}

void place_piece(int player, int row, int col, int size) {
    board[row][col].player_id = player;
    board[row][col].size = size;

    Inventory *inv = &inventories[player];
    if (size == 1) inv->small--;
    else if (size == 2) inv->medium--;
    else inv->large--;
}

int check_ordered_line(int player) {
    int i, j;
    // Check rows
    for (i = 0; i < 3; i++) {
        int sizes[3];
        for (j = 0; j < 3; j++) {
            if (board[i][j].player_id != player) break;
            sizes[j] = board[i][j].size;
        }
        if (j == 3 && sizes[0] == 1 && sizes[1] == 2 && sizes[2] == 3)
            return 1;
    }

    // Check columns
    for (j = 0; j < 3; j++) {
        int sizes[3];
        for (i = 0; i < 3; i++) {
            if (board[i][j].player_id != player) break;
            sizes[i] = board[i][j].size;
        }
        if (i == 3 && sizes[0] == 1 && sizes[1] == 2 && sizes[2] == 3)
            return 1;
    }

    // Check diagonals
    if (board[0][0].player_id == player &&
        board[1][1].player_id == player &&
        board[2][2].player_id == player) {
        int sizes[3] = {board[0][0].size, board[1][1].size, board[2][2].size};
        if (sizes[0] == 1 && sizes[1] == 2 && sizes[2] == 3)
            return 1;
    }

    if (board[0][2].player_id == player &&
        board[1][1].player_id == player &&
        board[2][0].player_id == player) {
        int sizes[3] = {board[0][2].size, board[1][1].size, board[2][0].size};
        if (sizes[0] == 1 && sizes[1] == 2 && sizes[2] == 3)
            return 1;
    }

    return 0;
}

int is_board_full() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j].player_id == 0)
                return 0;
    return 1;
}

void broadcast(int p1, int p2, char *msg) {
    send(p1, msg, strlen(msg), 0);
    send(p2, msg, strlen(msg), 0);
}

int main() {
    int server_fd, player1_fd, player2_fd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[1024] = {0};
    int current_player = 1;

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr*)&address, sizeof(address));
    listen(server_fd, 2);

    printf("Waiting for Player 1...\n");
    player1_fd = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    send(player1_fd, "You are Player 1\n", 17, 0);

    printf("Waiting for Player 2...\n");
    player2_fd = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    send(player2_fd, "You are Player 2\n", 17, 0);

    // Initialize inventories
    inventories[1] = (Inventory){2,2,2};
    inventories[2] = (Inventory){2,2,2};

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int fd = (current_player == 1) ? player1_fd : player2_fd;
        int opponent_fd = (current_player == 1) ? player2_fd : player1_fd;

        send(fd, "Your move (row col size):\n", 26, 0);
        recv(fd, buffer, sizeof(buffer), 0);

        int row, col, size;
        sscanf(buffer, "%d %d %d", &row, &col, &size);

        if (!is_valid_move(current_player, row, col, size)) {
            send(fd, "Invalid move. Try again.\n", 25, 0);
            continue;
        }

        place_piece(current_player, row, col, size);

        print_board();

        char move_msg[256];
        snprintf(move_msg, sizeof(move_msg), "Player %d placed size %d at (%d,%d)\n", current_player, size, row, col);
        broadcast(player1_fd, player2_fd, move_msg);

        if (check_ordered_line(current_player)) {
            char win_msg[256];
            snprintf(win_msg, sizeof(win_msg), "Player %d wins by order!\n", current_player);
            broadcast(player1_fd, player2_fd, win_msg);
            break;
        }

        if (is_board_full()) {
            broadcast(player1_fd, player2_fd, "The game is a draw.\n");
            break;
        }

        current_player = (current_player == 1) ? 2 : 1;
    }

    close(player1_fd);
    close(player2_fd);
    close(server_fd);
    return 0;
}
